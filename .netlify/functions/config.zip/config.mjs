
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/config.mjs
var config_default = async () => {
  const key = process.env.GOOGLE_MAPS_KEY;
  if (!key) return new Response(JSON.stringify({ error: "GOOGLE_MAPS_KEY not set." }), { status: 500, headers: { "content-type": "application/json" } });
  return new Response(JSON.stringify({ key }), { status: 200, headers: { "content-type": "application/json" } });
};
var config = { path: "/api/config" };
export {
  config,
  config_default as default
};
